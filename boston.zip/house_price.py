import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn import metrics

df = pd.read_csv("..\\train.csv")
df_test = pd.read_csv("..\\test.csv")
X = df.iloc[:,:-1].values
y = df["MEDV"].values
X_test = df_test.values
#X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=0)

#train
model = RandomForestRegressor(n_estimators=100)
model.fit(X,y)

#perict
y_predict = model.predict(X_test)
d = {'ID':df_test['ID'].values,'MEDV':y_predict}
pd.DataFrame(d).to_csv("..//submission.csv")
#metrics
#print metrics.mean_squared_error(y_test,y_predict)
