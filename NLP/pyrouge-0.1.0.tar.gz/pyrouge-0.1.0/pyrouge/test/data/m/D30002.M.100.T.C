<html>
<head>
<title>dummy title</title>
</head>
<body bgcolor="white">
<a name="1">[1]</a> <a href="#1" id=1>Hurricane Mitch, category 5 hurricane, brought widespread death and destruction to Central American.</a>
<a name="2">[2]</a> <a href="#2" id=2>Especially hard hit was Honduras where an estimated 6,076 people lost their lives.</a>
<a name="3">[3]</a> <a href="#3" id=3>The hurricane, which lingered off the coast of Honduras for 3 days before moving off, flooded large areas, destroying crops and property.</a>
<a name="4">[4]</a> <a href="#4" id=4>The U.S. and European Union were joined by Pope John Paul II in a call for money and workers to help the stricken area.</a>
<a name="5">[5]</a> <a href="#5" id=5>President Clinton sent Tipper Gore, wife of Vice President Gore to the area to deliver much needed supplies to the area, demonstrating U.S. commitment to the recovery of the region.</a>
<a name="6">[6]</a> <a href="#6" id=6></a>
</body>
</html>